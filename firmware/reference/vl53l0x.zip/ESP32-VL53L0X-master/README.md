# ESP32-VL53L0X

VL53L0X library
- Platform: ESP-IDF (e.g. ESP32)
- See include file for details of functions

Copyright © 2019 Adrian Kennard, Andrews & Arnold Ltd. See LICENCE file for details. GPL 3.0
